from pydantic import BaseModel

class Shop(BaseModel):
    address: str